# Meteor Addon Template

A template to allow easy usage of the Meteor Addon API.

### How to use:  
- Clone this project
- Use this template to create new modules/commands
- Run the mod with Meteor.